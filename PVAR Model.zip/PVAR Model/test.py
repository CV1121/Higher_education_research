import os
filepath = r'C:\Python\2020.xlsx'  # 替换为实际路径

# 检查文件基本信息
print(f"文件存在: {os.path.exists(filepath)}")
print(f"文件大小: {os.path.getsize(filepath)} bytes")

# 尝试以二进制模式读取
try:
    with open(filepath, 'rb') as f:
        header = f.read(4)
        print(f"文件头: {header}")  # 正常xlsx应以PK\x03\x04开头
except Exception as e:
    print(f"读取失败: {str(e)}")