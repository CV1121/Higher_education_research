"""
PVAR-style analysis with statsmodels.VAR
Required file: higher_ed_panel.csv
Columns: province,year,RES,INTL,OUT[,lngdp_pc,rdi]
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.tsa.api import VAR
from statsmodels.tsa.stattools import grangercausalitytests

# 1. 读入数据
df = pd.read_csv('higher.csv')

# 2. 基础检查
assert {'province', 'year', 'RES', 'INTL', 'OUT'}.issubset(df.columns), \
    "缺少必要列！请检查 CSV 文件列名。"

# 3. 平衡面板：31 省 × 3 年（2020-2022）
df = df.sort_values(['province', 'year'])
min_year, max_year = 2020, 2022
expected_provs = 31
expected_rows = expected_provs * (max_year - min_year + 1)
if len(df) != expected_rows:
    print(f"⚠️ 数据行数={len(df)}，期望={expected_rows}，请检查缺失值！")

# 4. 去除个体固定效应（Helmert / within 变换）
vars_endog = ['RES', 'INTL', 'OUT']
for v in vars_endog:
    df[f'{v}_demean'] = df.groupby('province')[v].transform(lambda x: x - x.mean())

# 5. 构造“堆叠”时间序列（按 year 排序）
panel_ts = df.sort_values(['year', 'province'])[
    [f'{v}_demean' for v in vars_endog]
].dropna()

# 6. VAR 建模
model = VAR(panel_ts)
# 选阶：因 T=3，maxlags 只能取 1
opt_lag = 1
results = model.fit(maxlags=opt_lag)
print(f"选用滞后阶数：{opt_lag}")

# 7. 脉冲响应（IRF）
irf = results.irf(periods=6)
irf.plot(orth=True, impulse='RES_demean', response='OUT_demean')
plt.suptitle('.')
plt.tight_layout()
plt.savefig('irf_RES_OUT.png', dpi=300)
plt.show()

# 8. Granger 因果检验
print("\n=== Granger 因果检验 ===")
gc_res_out = grangercausalitytests(
    panel_ts[['OUT_demean', 'RES_demean']], maxlag=opt_lag, verbose=True
)
gc_intl_out = grangercausalitytests(
    panel_ts[['OUT_demean', 'INTL_demean']], maxlag=opt_lag, verbose=True
)